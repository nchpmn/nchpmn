<?php

class TextField extends InputField {
  public $type = 'text';
}
