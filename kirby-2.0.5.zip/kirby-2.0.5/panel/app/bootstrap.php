<?php

if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR);

include(__DIR__ . DS . 'panel.php');
include(__DIR__ . DS . 'panel' . DS . 'roots.php');
include(__DIR__ . DS . 'panel' . DS . 'urls.php');
include(__DIR__ . DS . 'helpers.php');