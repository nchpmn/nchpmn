<header id="topbar" class="topbar">
  <?php echo new Snippet('menu') ?>
  <?php echo !empty($breadcrumb) ? $breadcrumb : null ?>
</header>