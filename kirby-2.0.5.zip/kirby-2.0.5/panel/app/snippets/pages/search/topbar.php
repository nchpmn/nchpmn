<header id="topbar" class="topbar">

  <?php echo $menu ?>
  <?php echo $breadcrumb ?>

  <a data-shortcut="esc" class="nav-icon nav-icon-right" href="<?php echo $close ?>">
    <?php i('times fa-lg') ?>
  </a>

</header>
